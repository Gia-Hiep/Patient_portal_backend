package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

    public class BaseTest {
    public void slowStep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    public void highlight(WebElement el) {
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].style.outline='3px solid red'; arguments[0].style.backgroundColor='#fff3cd';",
                el
        );
    }

    protected WebDriver driver;
    protected String baseUrl = "http://localhost:3000";

    @BeforeMethod
    public void setup() {
        WebDriverManager.chromedriver().setup();

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        // implicit wait cơ bản (tránh lỗi findElement quá sớm)
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        // mặc định vào trang login
        driver.get(baseUrl + "/login");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

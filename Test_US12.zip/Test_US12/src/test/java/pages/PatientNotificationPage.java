package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PatientNotificationPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ===== Constructor =====
    public PatientNotificationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ===== LOCATORS (React-friendly) =====

    // 👉 Link menu "Thông báo"
    private By notificationMenu =
            By.xpath("//a[contains(text(),'Thông báo')]");

    // 👉 Danh sách thông báo (card / item)
    private By notificationItems =
            By.xpath("//div[contains(@class,'notification') or contains(@class,'card')]");

    // 👉 Nội dung text của thông báo
    private By notificationMessage =
            By.xpath(".//*[contains(@class,'message') or self::p or self::span]");

    // 👉 Trạng thái không có thông báo
    private By emptyMessage =
            By.xpath("//*[contains(text(),'Không có') and contains(text(),'thông báo')]");

    // ===== ACTIONS =====

    /**
     * Mở trang thông báo của bệnh nhân
     */
    public void openNotificationPage() {
        wait.until(ExpectedConditions.elementToBeClickable(notificationMenu))
                .click();
    }

    /**
     * Kiểm tra có ít nhất 1 thông báo
     */
    public boolean hasAnyNotification() {
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(notificationItems));
            return driver.findElements(notificationItems).size() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Kiểm tra có thông báo chứa nội dung mong muốn
     */
    public boolean isNotificationDisplayed(String expectedMessage) {

        wait.until(ExpectedConditions.presenceOfElementLocated(notificationItems));

        List<WebElement> notifications =
                driver.findElements(notificationItems);

        for (WebElement item : notifications) {
            String text = item.getText();
            if (text.contains(expectedMessage)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Lấy tổng số thông báo
     */
    public int getNotificationCount() {
        return driver.findElements(notificationItems).size();
    }

    /**
     * Kiểm tra trạng thái không có thông báo
     */
    public boolean isEmptyNotificationDisplayed() {
        try {
            return wait.until(ExpectedConditions
                            .visibilityOfElementLocated(emptyMessage))
                    .isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}

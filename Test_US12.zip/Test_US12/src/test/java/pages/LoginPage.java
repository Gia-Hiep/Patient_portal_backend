package pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Username / Email
    private By usernameInput = By.xpath(
            "//input[contains(@placeholder,'@') or contains(@placeholder,'patient')]"
    );

    // Password
    private By passwordInput = By.xpath(
            "//input[@type='password']"
    );

    // Button Đăng nhập
    private By loginButton = By.xpath(
            "//button[@type='submit' and contains(text(),'Đăng nhập')]"
    );

    public void login(String username, String password) {

        wait.until(ExpectedConditions.visibilityOfElementLocated(usernameInput))
                .sendKeys(username);

        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordInput))
                .sendKeys(password);

        wait.until(ExpectedConditions.elementToBeClickable(loginButton))
                .click();
    }
}

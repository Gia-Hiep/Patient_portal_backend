package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class DoctorNotificationPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public DoctorNotificationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    // 👉 Bệnh nhân đầu tiên (đúng theo React: ul > li)
    private By firstPatient = By.xpath("//ul/li[1]");

    // 👉 Dòng hiển thị tên BN trong detail
    private By patientDetailTitle = By.xpath("//div[@class='patient-detail']//h3");

    private By txtMessage = By.xpath("//div[@class='patient-detail']//textarea");
    private By btnSend = By.xpath("//button[contains(text(),'Gửi')]");
    private By successMsg = By.xpath("//p[contains(text(),'thành công')]");

    public void selectFirstPatient() {
        wait.until(ExpectedConditions.elementToBeClickable(firstPatient)).click();

        // 🔥 QUAN TRỌNG: chờ detail load xong
        wait.until(ExpectedConditions.visibilityOfElementLocated(patientDetailTitle));
    }

    public void sendNotification(String message) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(txtMessage))
                .clear();
        driver.findElement(txtMessage).sendKeys(message);

        driver.findElement(btnSend).click();
    }

    public boolean isSuccessDisplayed() {
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(successMsg)
        ).isDisplayed();
    }
}

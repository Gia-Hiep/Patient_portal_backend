package tests;

public class AuthorizationTest {
}

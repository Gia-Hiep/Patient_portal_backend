package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.DoctorNotificationPage;

import java.time.Duration;

public class DoctorSendNotificationTest extends BaseTest {

    @Test
    public void fullFlow_DoctorSendNotification_ThenPatientView() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        /* ===============================
           1. DOCTOR LOGIN
         =============================== */
        Thread.sleep(2000);

        LoginPage login = new LoginPage(driver);
        login.login("doctor01", "12345678");

        wait.until(ExpectedConditions.urlContains("/dashboard"));
        Thread.sleep(3000);

        Assert.assertTrue(driver.getCurrentUrl().contains("/dashboard"));

        /* ===============================
           2. VÀO TRANG US12
         =============================== */
        driver.get(baseUrl + "/doctor/lab-notify");

        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@placeholder='Tìm kiếm bệnh nhân']")
        ));
        Thread.sleep(4000);

        /* ===============================
           3. CHỌN BN & GỬI THÔNG BÁO
         =============================== */
        DoctorNotificationPage doctorPage = new DoctorNotificationPage(driver);

        doctorPage.selectFirstPatient();
        Thread.sleep(5000);

        doctorPage.sendNotification("Kết quả xét nghiệm của bạn đã sẵn sàng.");
        Thread.sleep(4000);

        Assert.assertTrue(
                doctorPage.isSuccessDisplayed(),
                "Không hiển thị thông báo gửi thành công"
        );

        /* ===============================
           4. QUAY VỀ DASHBOARD
         =============================== */
        driver.get(baseUrl + "/dashboard");
        wait.until(ExpectedConditions.urlContains("/dashboard"));
        Thread.sleep(3000);

        /* ===============================
           5. LOGOUT DOCTOR
         =============================== */
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Đăng xuất')]")
        )).click();

        wait.until(ExpectedConditions.urlContains("/login"));
        Thread.sleep(3000);

        /* ===============================
           6. PATIENT LOGIN
         =============================== */
        login.login("vanhai1233@gmail.com", "vanhai1108");

        wait.until(ExpectedConditions.urlContains("/dashboard"));
        Thread.sleep(4000);

        /* ===============================
           7. VÀO THÔNG BÁO CHƯA ĐỌC
         =============================== */
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[contains(@href,'notifications')]")
        )).click();

        Thread.sleep(4000);

        /* ===============================
           8. XEM THÔNG BÁO
         =============================== */
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//div[contains(@class,'notification-item')]")
        )).click();

        Thread.sleep(4000);

    }
}
